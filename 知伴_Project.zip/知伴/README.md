# ZenTutor-AI

An extensible, profile-driven personalized AI tutoring engine powered by Gemini.

## Key Features
- **Profile-Aware**: Dynamic system prompting based on student technical background and interests.
- **Contextual Memory**: Maintains session history for coherent multi-turn learning.
- **Socratic Method**: Encourages deep thinking rather than just providing answers.

## Setup
1. Clone the repo.
2. Install dependencies: `pip install -r requirements.txt`.
3. Copy `.env.example` to `.env` and add your `GEMINI_API_KEY`.
4. Run the application: `python main.py`.

## Directory Structure
- `core/`: Core LLM logic and agent definitions.
- `data/`: Student profiles and session logs.
- `utils/`: Helper functions for CLI and config management.
