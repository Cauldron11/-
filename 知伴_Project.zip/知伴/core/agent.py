import google.generativeai as genai
import json

class TutorAgent:
    def __init__(self, api_key: str, profile: dict):
        genai.configure(api_key=api_key)
        self.profile = profile
        self.model_name = "gemini-1.5-flash"
        
        self.system_prompt = self._generate_system_instruction()
        self.model = genai.GenerativeModel(
            model_name=self.model_name,
            system_instruction=self.system_prompt
        )
        self.chat_session = self.model.start_chat(history=[])

    def _generate_system_instruction(self) -> str:
        return f"""
You are a professional AI Tutor. Your personality is encouraging yet rigorous.
Target Student Profile: {json.dumps(self.profile)}

Guidelines:
1. Adapt technical depth to the student's background.
2. Use metaphors related to their interests (e.g., Minecraft, Android) when explaining abstract concepts.
3. Use the Socratic method: ask guiding questions instead of giving direct answers immediately.
4. Keep responses concise and structured.
"""

    def chat(self, message: str) -> str:
        response = self.chat_session.send_message(message)
        return response.text
